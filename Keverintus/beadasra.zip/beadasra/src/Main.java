import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

enum Irany{Fel, Le, Jobbra, Balra};

public class Main{
	
	public static void main(String[] args)
	{
		
		/*Palya palya=new Palya(25,25,2,50,2,2);//20,20,2,40,0,2
		palya.palyatIr();
		palya.babutElhelyez();
		palya.szornyeketLerak();
		palya.kincseketLerak();
		JatekFrame frame=new JatekFrame(palya);
		*/
		KezdoPanel kp=new KezdoPanel();
		
//JatekFrame f=new JatekFrame(new Palya(25,25,2,35,2,2));
		
		
		
		
	}

	
}
